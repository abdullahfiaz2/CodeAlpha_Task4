//music-2:Alec-Benjamin, Let me down slowly
//music-3:Alex & Sierra,Little do you Know
//music-4:Indila, Dernière Danse
//music-5:Arjit Singh,Veh kamleya
//music-6:Tones and I, Dance Monkey
//music-7: Vishal Mishra ,Pehle Bhi Main
let allMusic =[

    {
        name:"Runaway-Acapella",
        artist:"AURORA",
        img:"music-1",
        src:"music-1",
    },
    {
        name:"Let me down slowly",
        artist:"Alec Benjamin",
        img:"music-2",
        src:"music-2",
    },
    {
        name:"Little do you Know",
        artist:"Alex & Sierra",
        img:"music-3",
        src:"music-3",
    },
    {
        name:"Dernière Danse",
        artist:"Indila",
        img:"music-4",
        src:"music-4",
    },
    {
        name:"Pehle Bhi Main",
        artist:"Vishal Mishra",
        img:"music-5",
        src:"music-5",
    },
    {
        name:"Dance Monkey",
        artist:"Tones and I",
        img:"music-6",
        src:"music-6",
    },
    {
        name:"Veh kamleya",
        artist:"Arjit Singh",
        img:"music-7",
        src:"music-7",
    },
    
    
    ];